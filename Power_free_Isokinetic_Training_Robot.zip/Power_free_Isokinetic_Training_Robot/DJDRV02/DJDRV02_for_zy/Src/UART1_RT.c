/**
  ******************************************************************************
  * File Name          : UART2_RT.c
  * Description        : ����2��ͨ�Ŵ��������������ݽӿ�,�ɼ��ߵ�5��8������
  ******************************************************************************
  *
  */
#include "stm32f4xx_hal.h"
#include "string.h"
#include "math.h"
#include "gPara.h"
#include	"motor.h"
#include "ControlLab.h"
#define UARTPRO_GLOBALS 1
#include "UARTPro.h"


#ifndef UART1_DMA
#define UART1_DMA
#endif
USART_RECEIVETYPE UsartType1;
unsigned char uart1rxCnt=0;
int32_t speed_temp=0;//Feng
int32_t speed_temp1=0;
uint8_t alen=0;

//UART1�ĳ�ʼ��
void UART1_IT_Init(void)
{
		 HAL_UART_Receive_DMA(&huart1, UsartType1.usartDMA_rxBuf, RECEIVELEN);  
		__HAL_UART_ENABLE_IT(&huart1, UART_IT_IDLE);
}
//UART1�����ݽ���
void UART1_DMA_REVC(void)
{
    uint32_t temp;
		int32_t data;
  
    if((__HAL_UART_GET_FLAG(&huart1,UART_FLAG_IDLE) != RESET))  
    {   
        __HAL_UART_CLEAR_IDLEFLAG(&huart1);  
        HAL_UART_DMAStop(&huart1);  
        UsartType1.rx_len = RECEIVELEN - huart1.hdmarx->Instance->NDTR;  
        HAL_UART_Receive_DMA(&huart1,UsartType1.usartDMA_rxBuf,RECEIVELEN);
				
				//UART1_Send(UsartType1.usartDMA_rxBuf,UsartType1.rx_len);
				UsartType1.usartDMA_rxBuf[UsartType1.rx_len] = 0;
				////////////////////////////////////////////////////////////////////////////
				if((UsartType1.usartDMA_rxBuf[0] == 'v')&&(UsartType1.usartDMA_rxBuf[1] == 'i')&&(UsartType1.usartDMA_rxBuf[2] == 'e')
					&&(UsartType1.usartDMA_rxBuf[3] == 'w'))
				{//������ر�ͨ��
					if(UsartType1.usartDMA_rxBuf[5] == '1')
					{gc_TxView = 1;send_tick=0;}
					else
						gc_TxView = 0;
				}
				else if((UsartType1.usartDMA_rxBuf[0] == 'c')&&(UsartType1.usartDMA_rxBuf[1] == 'o')&&(UsartType1.usartDMA_rxBuf[2] == 'm')
					&&(UsartType1.usartDMA_rxBuf[3] == 'm'))
				{//������ر�ͨ��
					if(UsartType1.usartDMA_rxBuf[5] == '1')
					{gc_TxView = 1;send_tick=0;}
					else
						gc_TxView = 0;
				}
				else if((UsartType1.usartDMA_rxBuf[0] == 'm')&&(UsartType1.usartDMA_rxBuf[1] == 'o')&&(UsartType1.usartDMA_rxBuf[2] == 'd')
					&&(UsartType1.usartDMA_rxBuf[3] == 'e')) //���������µ�ģʽ����
				{
					
				}
				else if((UsartType1.usartDMA_rxBuf[0] == 's')&&(UsartType1.usartDMA_rxBuf[1] == 'p')&&(UsartType1.usartDMA_rxBuf[2] == 'e')
					&&(UsartType1.usartDMA_rxBuf[3] == 'e')&&(UsartType1.usartDMA_rxBuf[4] == 'd'))//�ٶ�����
				{
					sscanf(UsartType1.usartDMA_rxBuf,"speed=%d",&gt_MInfo.Set_Speed);
					if(gt_MInfo.Set_Speed == 0)
						gt_MInfo.mode = 0xB0;
					else
						gt_MInfo.mode = 0xB1;
					usr_Timer1_Init();
					//motor_enable(gt_MInfo.mode&0x01);
					gc_MotorModeSelect = 1; //PWM���
					
					//
					if(gt_MInfo.Set_Speed >= -3000 && gt_MInfo.Set_Speed<=3000)
					{
						if(gt_MInfo.Set_Speed > 0)
						{
							gc_MDir = 1;
							gi_DutyValue = 4200-gt_MInfo.Set_Speed;
						}
						else
						{
							gc_MDir = 0;
							gi_DutyValue = 4200+gt_MInfo.Set_Speed;
						}
					}
				}
				else if((UsartType1.usartDMA_rxBuf[0] == 'p')&&(UsartType1.usartDMA_rxBuf[1] == 'o')&&(UsartType1.usartDMA_rxBuf[2] == 'l')
					&&(UsartType1.usartDMA_rxBuf[3] == 'e')) //���ü�����
				{
					 sscanf(UsartType1.usartDMA_rxBuf,"pole=%d",&data);
					if((data <= 32)&&(data >= 1))
					{
						gc_NumOfPole = data;
						I2C_EEPROM_WriteBuffer(0x20,&gc_NumOfPole,1);
					}
				}
				else if((UsartType1.usartDMA_rxBuf[0] == 'c')&&(UsartType1.usartDMA_rxBuf[1] == 'o')&&(UsartType1.usartDMA_rxBuf[2] == 'd')
					&&(UsartType1.usartDMA_rxBuf[3] == 'e')&&(UsartType1.usartDMA_rxBuf[4] == 'r')) //����ѡ������������Hall��ű��룩
				{
					if(UsartType1.usartDMA_rxBuf[6] == '1')
						is_Hall_or_Encoder = 1;
					else if(UsartType1.usartDMA_rxBuf[6] == '2')
						is_Hall_or_Encoder = 2;
					else;
					I2C_EEPROM_WriteBuffer(0x21,&is_Hall_or_Encoder,1);
				}
				else if((UsartType1.usartDMA_rxBuf[0] == 'z')&&(UsartType1.usartDMA_rxBuf[1] == 'e')&&(UsartType1.usartDMA_rxBuf[2] == 'r')
					&&(UsartType1.usartDMA_rxBuf[3] == 'o'))   //����趨
				{
					if(UsartType1.usartDMA_rxBuf[5] == '1')
					{
						gc_CalZeroFlag = 1;
					}
				}
				else;
				////////////////////////////////////////////////////////////////////////////
				if(UsartType1.rx_len == 8)
				{
					if((UsartType1.usartDMA_rxBuf[0] == 0xAA)&&(UsartType1.usartDMA_rxBuf[1] == 0x55)&&(UsartType1.usartDMA_rxBuf[6] == 0x0D)&&(UsartType1.usartDMA_rxBuf[7] == 0x0A))
					{
						if(UsartType1.usartDMA_rxBuf[2] == 0x01) //���õ�ǰ�Ĺ���ģʽ
						{
							gt_MInfo.mode = UsartType1.usartDMA_rxBuf[3];
						}
						else if(UsartType1.usartDMA_rxBuf[2] == 0x02)  //��ȡPID������
						{
							alen = UsartType1.usartDMA_rxBuf[3]-1;
							if(alen < 7)
							{
								memcpy(TXBuf,&gt_PID[alen].header[0],52);
								delay_us1(100000);  //��ʱ10mS
								UART1_Send(TXBuf,52);   //
								delay_us1(100000);
							}
						}
						else if(UsartType1.usartDMA_rxBuf[2] == 0x03)  //��������
						{
							gt_MInfo.cmd = UsartType1.usartDMA_rxBuf[3];
						}
						else if(UsartType1.usartDMA_rxBuf[2] == 0xF0) //��λ
						{
							gt_MInfo.cmd = UsartType1.usartDMA_rxBuf[4];
						}
						else;
					}
				}
				else if(UsartType1.rx_len == 16)
				{
					if((UsartType1.usartDMA_rxBuf[0] == 0xAA)&&(UsartType1.usartDMA_rxBuf[1] == 0x55)&&(UsartType1.usartDMA_rxBuf[14] == 0x0D)&&(UsartType1.usartDMA_rxBuf[15] == 0x0A))
					{
						if(UsartType1.usartDMA_rxBuf[2] == 0x04) //����ת�ٲ�����
						{
							memcpy(&gt_MRun.header[0],UsartType1.usartDMA_rxBuf,16);
							if(gt_MRun.mode < 10)
								gt_MInfo.mode = gt_MRun.mode;
							if(gt_MRun.value < 4200)
								gt_MInfo.Set_Speed = gt_MRun.value;
							if(gt_MInfo.Set_Speed == 0)
								motor_enable(0);
							else
								motor_enable(1);
							//gt_MInfo.Status = UsartType1.usartDMA_rxBuf[13]<<8 | UsartType1.usartDMA_rxBuf[12];
							
							
							if((gt_MInfo.Set_Speed >= -3000 && gt_MInfo.Set_Speed<=3000)&&(gt_MInfo.mode==1)) //��������ģʽ��
							{
								gc_MotorModeSelect = 1; //PWM���
								usr_Timer1_Init();
								if(gt_MInfo.Set_Speed > 0)
								{
									gc_MDir = 1;
									gi_DutyValue = 4200-gt_MInfo.Set_Speed;
								}
								else
								{
									gc_MDir = 0;
									gi_DutyValue = 4200+gt_MInfo.Set_Speed;
								}
							}
							else if(gt_MInfo.mode==5)  //����ģʽ1 Dynamic Braking
							{
								gc_MotorModeSelect = 5; //����IO����PWM���
								motor_single_contorl_mode(0,0,0,0);
								if((gt_MInfo.Set_Speed >= 0 && gt_MInfo.Set_Speed<=1000))
								{
									gi_DutyValue = gt_MInfo.Set_Speed/10;
								}
							}
							else if(gt_MInfo.mode==6)  //����ģʽ2 Plugging Braking
							{
								gc_MotorModeSelect = 6; //����IO����PWM���
								usr_Timer1_Init();
								if((gt_MInfo.Set_Speed >= 0) && (gt_MInfo.Set_Speed<=3000))
								{
									gi_DutyValue = (3000 - gt_MInfo.Set_Speed)/3;
									Ctrl_Mode4_Pro(gi_DutyValue);
								}
							}
							else;
						}
					}
				}
				else if(UsartType1.rx_len == 32)
				{
					if((UsartType1.usartDMA_rxBuf[0] == 0xAA)&&(UsartType1.usartDMA_rxBuf[1] == 0x55)&&(UsartType1.usartDMA_rxBuf[30] == 0x0D)&&(UsartType1.usartDMA_rxBuf[31] == 0x0A))
					{
						if(UsartType1.usartDMA_rxBuf[2] == 0x02)  //����PID����
						{
							if((UsartType1.usartDMA_rxBuf[3]>=1)&&(UsartType1.usartDMA_rxBuf[3]<=10))
							{
								alen = UsartType1.usartDMA_rxBuf[3]-1;
								memcpy(&gt_PID[alen].mode,&UsartType1.usartDMA_rxBuf[3],27);
								I2C_EEPROM_WriteBuffer((alen+8)*32,&gt_PID[alen].mode,27);
								if(gc_MotorModeSelect == 6)
									PID_Init(&gt_Speed,  gt_PID[5].P, gt_PID[5].I, gt_PID[5].D, 0, 0,gt_PID[5].S); //Intial PID, Feng 
							}
						}
					}
				}
				else;
				////////////////////////////////////////////////////////////////////////////
    }
		else if((__HAL_UART_GET_FLAG(&huart1,UART_FLAG_ORE) != RESET))
		{
				__HAL_UART_CLEAR_OREFLAG(&huart1);  
				HAL_UART_DMAStop(&huart1);
				temp = huart1.hdmarx->Instance->NDTR;
				HAL_UART_Receive_DMA(&huart1,UsartType1.usartDMA_rxBuf,RECEIVELEN);
		}
		else
		{
				HAL_UART_DMAStop(&huart1);  
				temp = huart1.hdmarx->Instance->NDTR;  
				HAL_UART_Receive_DMA(&huart1,UsartType1.usartDMA_rxBuf,RECEIVELEN);
		}
}


//UART1�Ĵ������ݷ���
void UART1_Send(uint8_t *TX1_DMABuf,  uint16_t iDMA_Index)
{
#if defined(UART1_DMA)
    HAL_UART_Transmit_DMA(&huart1,TX1_DMABuf,iDMA_Index);
    iDMA_Index=0;
#endif
}
//���ݳ�ʼ��
void DataInit(void)
{
	uint32_t tmpdata1;
	int32_t tmpdata2;
	ST_PID tmpPID;
	gc_TxView = 0;
	gc_TxFormat = 0;
	
	//�����ز�����ʼ��
	gc_MotorModeSelect = 6;
	is_Hall_or_Encoder = 2; //ѡ�������
	gc_NumOfPole = 7;   //������
	gc_ReductionRatio = 1; //���ٱ�
	gi_ZeroValue = 0;  //���У׼��ֵ
	gc_CalZeroFlag = 0; //���У׼�ı�־
	usr_Timer1_Init();
	//===============
	I2C_EEPROM_ReadBuffer(0x20,DataSave,16);
	if(DataSave[0]>=1 && DataSave[0]<=32)   //��ȡ������
		gc_NumOfPole = DataSave[0];
	if(DataSave[1]>=1 && DataSave[1]<=2)    //��ȡ���뷽ʽ
		is_Hall_or_Encoder = DataSave[1];
	tmpdata1 = (uint32_t)DataSave[3]<<8 | DataSave[2];  //��ȡ���ٱ�
	if((tmpdata1 >=1) && (tmpdata1<=100))
		gc_ReductionRatio = tmpdata1;
	tmpdata1 = (uint32_t)DataSave[6]<<16 | (uint32_t)DataSave[5]<<8 | DataSave[4];  //��ȡ����ֵ
	if(tmpdata1<=131072)
		gi_ZeroValue = tmpdata1;// - 600/(gc_NumOfPole*2);
	if(DataSave[8]>=1 && DataSave[8]<=6)   //��ȡ�ű���������Ӧ�Ļ���ֵ
		gc_ZeroHall = DataSave[8];
	
	for(int i=0;i<7;i++) //PID��ֵ
	{
		gt_PID[i].header[0] = 0xBB;
		gt_PID[i].header[1] = 0x44;
		gt_PID[i].key = 2;
		gt_PID[i].mode = i+1;
		gt_PID[i].S = 0;
		gt_PID[i].tail[0] = 0x0D;
		gt_PID[i].tail[1] = 0x0A;
		//=========��EEPROM�ж�ȡPID������============
		I2C_EEPROM_ReadBuffer(0x100+i*32,&tmpPID.mode,27);
		if(tmpPID.mode == i+1)
		{
			memcpy(&gt_PID[i].mode,&tmpPID.mode,27);
		}
	}
	//test motor
	PID_Init(&gt_Speed, 0.05, 0, 1, 0, 0,1); //Intial PID, Feng 
	if(gc_MotorModeSelect == 6)
	{
		PID_Init(&gt_Speed,  gt_PID[5].P, gt_PID[5].I, gt_PID[5].D, 0, 0,gt_PID[5].S); //Intial PID, Feng 
	}
	TX3Buf[0] = '1';
	
	gt_MInfo.header[0] = 0xBB;
	gt_MInfo.header[1] = 0x44;
	gt_MInfo.tail[0] = 0x0D;
	gt_MInfo.tail[1] = 0x0A;
}

//���ݷ��ͺ���
void uart_sendDataFun(void)
{
	if(gc_TxView == 1)
	{
		if(DMA_Len > 530)
			DMA_Len = 0;
		if(gc_TxFormat == 0)  //Ĭ�ϵ��������
		{
			gt_MInfo.Status = (gt_MInfo.Status &0xFF00) |gc_Hall |0x000;
	//		gt_MInfo.mot_spped = gi_MotorSpeed;
	//		gt_MInfo.NC = (int)speed_temp;
			memcpy(&TXBuf[DMA_Len],&gt_MInfo.header[0],52);
			DMA_Len += 52;
		}
		else if(gc_TxFormat == 1)
		{
			
		}
		else if(gc_TxFormat == 2)
		{
			
		}
		else;
		
		if(send_tick < 3)
		{
				send_tick=send_tick+1;
		}
		else
		{
			UART1_Send(TXBuf,156);
			DMA_Len = 0;
			send_tick = 0;
			LED2_Toggle;
		}
	}
	
	
}

