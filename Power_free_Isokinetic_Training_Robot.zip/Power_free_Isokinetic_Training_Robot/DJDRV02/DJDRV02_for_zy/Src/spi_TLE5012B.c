/**
  ******************************************************************************
  * @file    spi_TLE5012B.c
  * @author  Keith Cheung
  * @version V3.5.0
  * @date    13-MAY-2017
  * @brief   This file contains the headers of the spi_TLE5012B.
  ******************************************************************************
  * @attention
  *
  *
  * <h2><center>&copy; COPYRIGHT 2017</center></h2>
  ******************************************************************************
  */
	
#include "stm32f4xx_hal.h"
#include "spi_TLE5012B.h"
//#include "PublicSet.h"
void TLE_SPIWrite(uint16_t reg,uint16_t buf);
void TLE_SPIRead(uint16_t reg,uint16_t *buf,uint16_t len);

//uint16_t TLE_Angle,Angle_Speed,TLE_Offset_Angle;

//spi_TLE5012B.H ���м�Ҫ˵��

void SPIDelay( uint16_t i )
{
   while( i-- );
}

void TLEDOPP(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	__HAL_RCC_GPIOB_CLK_ENABLE();
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);
	GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

void TLEDOOD(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	__HAL_RCC_GPIOB_CLK_ENABLE();
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);
	GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

uint16_t u16Command = 0xFFFF;
	uint16_t u16Data = 0x0000;	//set open_drain mode
	uint16_t u16Safe = 0x0000 ;
uint16_t TLEData[32];
void SPI5012B_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
//	uint16_t u16Command = 0xFFFF;
//	uint16_t u16Data = 0x0000;	//set open_drain mode
//	uint16_t u16Safe = 0x0000 ;
	__HAL_RCC_GPIOB_CLK_ENABLE();
	//	Change_SPIx_MOSI_Mode(GPIO_Mode_AF_OD);		//SPI MOSI��Ϊ��©ģʽ
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12|GPIO_PIN_15, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET);
	/*Configure GPIO pins : PB2 PB12 PB13 PB15 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
	GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB14 PB4 */
  GPIO_InitStruct.Pin = GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
	TLECS_1;
	TLECLK_0;
	TLEDO_1;
	
	/* Read STAT register */
	u16Command = 0x8001;
	TLE_SPIRead(u16Command,&TLEData[0],1);
	
	/* Write STAT register, set Slave_Number = 00  */
	u16Command = 0x0001;
	u16Data &= 0x9FFF;
	//u16Safe = TLE5012WriteReg(SPIx, u16Command, &u16Data);
	TLE_SPIWrite(u16Command,u16Data);
	
	/* Read STAT register, check write value valid */
	u16Command = 0x8001;
	//u16Safe = TLE5012ReadReg(SPIx, u16Command, &u16Data);
	TLE_SPIRead(u16Command,&TLEData[1],1);
	
	/* Read ACSTAT register */
	u16Command = READ_ACSTAT_VALUE;
	//u16Safe = TLE5012ReadReg(SPIx, u16Command, &u16Data);
	TLE_SPIRead(u16Command,&TLEData[2],1);
	
	/* Read MOD1 register */
	u16Command = RD_REG | WRITE_MOD1_VALUE;
	//u16Safe = TLE5012ReadReg(SPI1, u16Command, &u16Data);
	TLE_SPIRead(u16Command,&TLEData[3],1);
	
	/* Write MOD1 register */
	u16Command = WRITE_MOD1_VALUE;
	u16Data = MOD1_VALUE;
	//u16Safe = TLE5012WriteReg(SPIx, u16Command, &u16Data);
	TLE_SPIWrite(u16Command,u16Data);
	
	/* Read MOD1 register */
	u16Command = RD_REG | WRITE_MOD1_VALUE;
	//u16Safe = TLE5012ReadReg(SPI1, u16Command, &u16Data);
	TLE_SPIRead(u16Command,&TLEData[4],1);
	
	/* Read MOD2 register */
	u16Command = RD_REG | WRITE_MOD2_VALUE;
	//u16Safe = TLE5012ReadReg(SPI1, u16Command, &u16Data);
	TLE_SPIRead(u16Command,&TLEData[5],1);
	
	/* Write MOD2 register */
	u16Command = WRITE_MOD2_VALUE;
	u16Data = MOD2_VALUE;
	//u16Safe = TLE5012WriteReg(SPIx, u16Command, &u16Data);
	TLE_SPIWrite(u16Command,u16Data);
	
	/* Read MOD2 register, check write value valid */
	u16Command = RD_REG | WRITE_MOD2_VALUE;
	//u16Safe = TLE5012ReadReg(SPI1, u16Command, &u16Data);
	TLE_SPIRead(u16Command,&TLEData[6],1);
	
	/* Read MOD3 register */
	u16Command = RD_REG | WRITE_MOD3_VALUE;
	//u16Safe = TLE5012ReadReg(SPIx, u16Command, &u16Data);
	TLE_SPIRead(u16Command,&TLEData[7],1);
	
	/* Write MOD3 register */
	u16Command = WRITE_MOD3_VALUE;
	u16Data = MOD3_VALUE;
	//u16Safe = TLE5012WriteReg(SPIx, u16Command, &u16Data);
	TLE_SPIWrite(u16Command,u16Data);
	
	/* Read MOD3 register */
	u16Command = RD_REG | WRITE_MOD3_VALUE;
	//u16Safe = TLE5012ReadReg(SPIx, u16Command, &u16Data);
	TLE_SPIRead(u16Command,&TLEData[8],1);
	
	/* Read MOD4 register */
	u16Command = RD_REG | WRITE_MOD4_VALUE;
	//u16Safe = TLE5012ReadReg(SPI1, u16Command, &u16Data);
	TLE_SPIRead(u16Command,&TLEData[9],1);
	
	/* Write MOD4 register */
	u16Command = WRITE_MOD4_VALUE;
	u16Data = MOD4_VALUE;
	//u16Safe = TLE5012WriteReg(SPIx, u16Command, &u16Data);
	TLE_SPIWrite(u16Command,u16Data);
	
	/* Read MOD4 register */
	u16Command = RD_REG | WRITE_MOD4_VALUE;
	//u16Safe = TLE5012ReadReg(SPI1, u16Command, &u16Data);
	TLE_SPIRead(u16Command,&TLEData[10],1);
	
	TLECS_1;
	TLECLK_0;
	TLEDO_1;
}
//д�Ĵ���
void TLE_SPIWrite(uint16_t reg,uint16_t buf)
{
	uint16_t data,i;
	TLEDOPP();
	TLECLK_0;
	TLECS_0;
	SPIDelay(50);
	data = reg;
	for(i=0;i<16;i++)
	{
		TLECLK_1;
		if(data & 0x8000)
			TLEDO_1;
		else
			TLEDO_0;
		SPIDelay(50);
		TLECLK_0;
		data <<= 1;
		SPIDelay(50);
	}
	SPIDelay(50);
	data = buf;
	for(i=0;i<16;i++)
	{
		TLECLK_1;
		if(data & 0x8000)
			TLEDO_1;
		else
			TLEDO_0;
		SPIDelay(50);
		TLECLK_0;
		data <<= 1;
		SPIDelay(50);
	}
	TLEDO_1;
	TLECS_1;
}
//������
void TLE_SPIRead(uint16_t reg,uint16_t *buf,uint16_t len)
{
	uint16_t data,i,j;
	TLEDOPP();
	TLECLK_0;
	TLECS_0;
	SPIDelay(50);
	data = reg;
	for(i=0;i<16;i++)
	{
		TLECLK_1;
		if(data & 0x8000)
			TLEDO_1;
		else
			TLEDO_0;
		SPIDelay(50);
		TLECLK_0;
		data <<= 1;
		SPIDelay(50);
	}
	TLEDOOD();
	SPIDelay(50);
	for(j=0;j<len;j++)
	{
		//data = buf[j];
		data = 0;
		for(i=0;i<16;i++)
		{
			TLECLK_1;
			data <<= 1;
			SPIDelay(50);
			TLECLK_0;
			if(TLEDI)
				data |= 1;
			SPIDelay(50);
		}
		buf[j] = data;
	}
	TLEDO_1;
	TLECS_1;
}


//�õ� 0~359 ��
uint16_t ReadAngle(void)
{
	uint16_t data;
	TLE_SPIRead(READ_ANGLE_VALUE,&data,1);
	//data = (data & 0x7FFF);
	data = (data & 0x7FFF)*3600/32768;
	//return ( ReadValue(READ_ANGLE_VALUE) * 360 / 0x10000 );
	return data;
}

//�õ����ٶ�
uint16_t ReadSpeed(void)
{
	uint16_t data;
	TLE_SPIRead(READ_SPEED_VALUE,&data,1);
	data = data & 0x7FFF;
	//return ReadValue(READ_SPEED_VALUE);
	return data;
}

