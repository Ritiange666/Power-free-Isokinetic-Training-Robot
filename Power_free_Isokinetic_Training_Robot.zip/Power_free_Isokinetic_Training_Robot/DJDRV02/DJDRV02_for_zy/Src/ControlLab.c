#include "ControlLab.h"
#include "math.h"
PID_TypeDef gt_Speed; //define a global structure and in .h extern
//Each .cpp including .h, could use this global structure.
void PID_Init(PID_TypeDef *Speed, double Pgain, double Igain, double Dgain, double Iterm, double DeadBand,double K)
{
  Speed->Pgain=Pgain/K;
  Speed->Igain=Igain/K;
  Speed->Dgain=Dgain/K;
  Speed->Iterm=Iterm;
  Speed->SS_Error=DeadBand;
	Speed->result_pre=0;
}

int PID_Calc(PID_TypeDef *Speed, int Set_Point, int Process_Point, int Max_Value, int Min_Value)
{
  double Err,Pterm,Dterm,D_Iterm,Result;

  Speed->Set_Point = Set_Point;
  Speed->Process_Point = Process_Point;
	
  Err= Speed->Set_Point - Speed->Process_Point;
  if (fabs(Err) < Speed->SS_Error)
    Err=0;
  
  Pterm   = Err*(Speed->Pgain);
  D_Iterm = Err*(Speed->Igain);
  if (Speed->Iterm<=Max_Value)
    Speed->Iterm+=D_Iterm;  // Anti-saturation
  else
    Speed->Iterm=Max_Value;

  Dterm=(Err- Speed->Prev_Error) * Speed->Dgain;	
  Result=Pterm+Speed->Iterm+Dterm;


  Speed->Prev_Error=Err;

//   if (fabs(Err)<=(Speed->SS_Error)) // λ�ÿ��Ʋ������г�������˿��Լ��������Ĵ���
//     Result=0;
//   
//   if(Result==0)
//     Speed->SS_Error=3.0;	 // ������̬��Χ����ֹ�ؽ���Ŀ��㸽������
//   else
//     Speed->SS_Error=1.5;	 // ���ƶ�̬��Χ��������߾�̬����
	Result = Speed->result_pre + Result;//Position PID, if it was absolute PID,please comment this. 
	Speed->result_pre = Result;
	if(Speed->result_pre>Max_Value)
		Speed->result_pre=Max_Value;
	if(Speed->result_pre < -Max_Value)
		Speed->result_pre = -Max_Value;

	  if (fabs(Result)>Max_Value)
  {
	  if (Result>Max_Value)    
	    Result=Max_Value;
	  else
	    Result=-Max_Value;
  }
  else
  { 
	  if (fabs(Result)<Min_Value)
	  {
	    if (Result>0)
		    Result=Min_Value;
      else
		    Result=-Min_Value;
	  }
  } 
  return(Result);   
}
