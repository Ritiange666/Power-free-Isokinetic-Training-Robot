#ifndef __ControlLab_H
#define __ControlLab_H
// Feng
//Define structure for PID
typedef struct 
{
  double Set_Point; // Set point
  double Process_Point; // Process point

  double Pgain;
  double Igain;
  double Dgain;
  double Prev_Error; // Previous error
  
  double Iterm;

  double SS_Error;	// 	Steady-state error
  int Max_Value;
  int Min_Value;
	int result_pre;// for position PID from Feng
	
   int Flag_Loop;
}PID_TypeDef;

extern PID_TypeDef gt_Speed;
//Define structure for speed while initializing 
void PID_Init(PID_TypeDef *Speed, double Pgain, double Igain, double Dgain, double Iterm, double DeadBand,double K);
int PID_Calc(PID_TypeDef *Speed, int Set_Point, int Process_Point, int Max_Value, int Min_Value);



#endif
