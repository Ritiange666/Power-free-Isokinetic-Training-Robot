/**
  ******************************************************************************
  * @file    spi_TLE5012B.h 
  * @author  Keith Cheung
  * @version V3.5.0
  * @date    13-MAY-2017
  * @brief   This file contains the headers of the spi_TLE5012B.
  ******************************************************************************
  * @attention
  *
  *
  * <h2><center>&copy; COPYRIGHT 2017</center></h2>
  ******************************************************************************
  */
	
#ifndef _TLE5012B_H_
#define _TLE5012B_H_

#include "stm32f4xx_hal.h"

//extern uint16_t TLE_Angle, Angle_Speed, TLE_Offset_Angle;
/*
TLE5012B_E1000 ����˵��:

1:GND
2:MOSI
3:MISO
  DATA <= 120R => INTPUT stm32f PB13
  DATA <= 120R => OUTPUT stm32f PB15
4:SCK <= 120R => stm32f PB13
5:CSQ (CS) <= 120R => stm32f PB12
6:VDD +5V
*/

//���������á������š���Բ�������� ֱ�� 10 x �� 2mm

//SPI5012B_Init() ʱ�����������
#define TLECS_0 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_RESET)	//GPIO��Ϊ0
#define TLECS_1  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET) 	  //GPIO��Ϊ1

#define TLECLK_0 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_RESET)	//GPIO��Ϊ0
#define TLECLK_1  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_SET) 	  //GPIO��Ϊ1

#define TLEDO_0 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_RESET)	//GPIO��Ϊ0
#define TLEDO_1  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_SET) 	  //GPIO��Ϊ1

#define TLEDI 		HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_14)  //��ȡ������������
/*
//���������谴ʵ�ʸ���
#define SPI_TX_OFF {GPIOA->CRL&=0x0FFFFFFF;GPIOA->CRL|=0x40000000;}//��PA7��MOSI�����óɿ�©--����ģʽ
#define SPI_TX_ON  {GPIOA->CRL&=0x0FFFFFFF;GPIOA->CRL|=0xB0000000;}//��PA7��MOSI�����ó�����--���ģʽ��50MHz��

#define GPIO_CS_Pin_Name  GPIO_Pin_0
#define GPIO_CS_Pin_Type  GPIOB

//��������һ�㲻��䶯
#define SPI_CS_ENABLE  GPIO_ResetBits(GPIO_CS_Pin_Type, GPIO_CS_Pin_Name)       //Ƭѡ�ŵ�ƽ����
#define SPI_CS_DISABLE GPIO_SetBits(GPIO_CS_Pin_Type, GPIO_CS_Pin_Name)         //Ƭѡ�ŵ�ƽ����
//#define INDEX_ENABLE   GPIO_SetBits(GPIOA, GPIO_Pin_4)

//#define CLK_H GPIO_SetBits(GPIOA, GPIO_Pin_5)                 //ʱ�ӽ�PA5��ƽ����
//#define CLK_L GPIO_ResetBits(GPIOA, GPIO_Pin_5)               //ʱ�ӽ�PA5��ƽ����

//#define DATA_H	GPIO_SetBits(GPIOA, GPIO_Pin_6)                         //PA6��MISO����ƽ����
//#define DATA_L	GPIO_ResetBits(GPIOA, GPIO_Pin_6)                       //PA6��MISO����ƽ����
//#define READ_DATA	GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)
/* Exported define -----------------------------------------------------------*/
// TLE5012 ����״̬
#define        IN_IDEL                  0
#define        IN_RCV                   1
#define        IN_SEND                  2
/* SPI command for TLE5012 */
#define   WRITE               0						//SPI Write Operate
#define   READ                1         	//SPI Read Operate

#define   DUMMY_BYTE          0xFFFF      //��Ԫ�ֽ� SPI ��������

#define   WR_REG              0x0000      /* Command word ���λΪ 0 д���� */
#define   RD_REG              0x8000			/* Command word ���λΪ 1 ������ */

#define		LockValue_LADDR					0x0000	/* Command word lock 4bit addresses 0x00:0x04 */
#define		LockValue_HADDR					0x5000	/* Command word lock 4bit addresses 0x05:0x11 */

#define   UPD_CMD              0x0400      /* Command word the 10th bit is 1, Access to values in update buffer */

#define READ_STAT_VALUE			0x8001
#define READ_ACSTAT_VALUE		0x8011
#define READ_ANGLE_VALUE		0x8021
#define READ_SPEED_VALUE		0x8031			//0x8031

#define WRITE_MOD1_VALUE		0x5061							//0_1010_0_000110_0001
#define MOD1_VALUE	0x0001
#define WRITE_MOD2_VALUE		0x5081							//0_1010_0_001000_0001
#define MOD2_VALUE	0x0809
#define WRITE_MOD3_VALUE		0x5091							//0_1010_0_001001_0001
#define MOD3_VALUE	0x0000
#define WRITE_MOD4_VALUE		0x50E1							//0_1010_0_001110_0001
#define MOD4_VALUE	0x0080											//12Bit 4096 ���Լ���disable 0x0080; ���Լ���enable 0x0000

#define WRITE_IFAB_VALUE		0x50B1
#define IFAB_VALUE 					0x000D

/******* TLE5012�Ĵ�����ַ *******************************/
#define		STAT_ADDR 									0x00
#define		ACSTAT_ADDR 								0x01
#define		AVAL_ADDR 									0x02
#define		ASPD_ADDR 									0x03
#define		AREV_ADDR 									0x04

#define		FSYNC_ADDR 								0x05
#define		MOD_1_ADDR 										0x06
#define		SIL_ADDR 									0x07
#define		MOD_2_ADDR 										0x08
#define		MOD_3_ADDR 										0x09
#define		OFFX_ADDR 								0x0A
#define		OFFY_ADDR 								0x0B
#define		SYNCH_ADDR 								0x0C
#define		IFAB_ADDR 								0x0D
#define		MOD_4_ADDR 										0x0E

#define		TCO_Y_ADDR 								0x0F
#define		ADC_X_ADDR 										0x10
#define		ADC_Y_ADDR 										0x11
#define		IIF_CNT_ADDR 							0x20
/* Functionality mode */
#define REFERESH_ANGLE		0

void SPI5012B_Init(void);
void SPI_SendData16(uint16_t SendData);
uint16_t SPI_ReadData16(void);
uint16_t ReadAngle(void);
uint16_t ReadSpeed(void);
uint16_t ReadValue(uint16_t u16Value);
uint16_t SPIx_ReadWriteByte(uint16_t byte);
uint16_t TlE5012W_Reg(uint16_t Reg_CMD, uint16_t Reg_Data);
#endif
