/**
  ******************************************************************************
  * File Name          : UART2Pro.c
  * Description        : ����2��ͨ�Ŵ���
  ******************************************************************************
  *
  */
#include "stm32f4xx_hal.h"
#include "gPara.h"
#include "string.h"
#include "math.h"
#include "UARTPro.h"

#ifndef UART4_DMA
#define UART4_DMA
#endif
USART_RECEIVETYPE UsartType4;


void UART4_IT_Init(void)
{
		 HAL_UART_Receive_DMA(&huart4, UsartType4.usartDMA_rxBuf, RECEIVELEN);  
		__HAL_UART_ENABLE_IT(&huart4, UART_IT_IDLE);
}

void UART4_DMA_REVC(void)
{  
    uint32_t temp;  
  
    if((__HAL_UART_GET_FLAG(&huart4,UART_FLAG_IDLE) != RESET))  
    {   
        __HAL_UART_CLEAR_IDLEFLAG(&huart4);  
        HAL_UART_DMAStop(&huart4);  
        temp = huart4.hdmarx->Instance->NDTR;  
        UsartType4.rx_len =  RECEIVELEN - temp;   
        HAL_UART_Receive_DMA(&huart4,UsartType4.usartDMA_rxBuf,RECEIVELEN);
			
			//HAL_UART_Transmit_DMA(&huart4, &UsartType1.usartDMA_rxBuf[0], UsartType1.rx_len);		
			
        //if(UsartType4.rx_len >= 8)
				//{
					gt_MInfo.Mot_Cur = (uint32_t)((UsartType4.usartDMA_rxBuf[2] <<8) + UsartType4.usartDMA_rxBuf[3]);
					gt_MInfo.Mot_Vol = (uint32_t)((UsartType4.usartDMA_rxBuf[4] <<8) + UsartType4.usartDMA_rxBuf[5]);
					
				//}
				//UART4_Send(&UsartType4.usartDMA_rxBuf[0], UsartType4.rx_len);
    }  
}



void UART4_Send(uint8_t *TX4_DMABuf,  uint16_t iDMA_Index)
{
#if defined(UART4_DMA)
    HAL_UART_Transmit_DMA(&huart4,TX4_DMABuf,iDMA_Index);
    iDMA_Index=0;
#endif
}



