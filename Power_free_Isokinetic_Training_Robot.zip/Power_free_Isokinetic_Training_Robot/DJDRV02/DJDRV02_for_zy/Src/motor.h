/*
** =============================================================================
** motor.h :                        -- by ZSC     2021-12-30
**
** 	Some useful Parameter.
**    
** =============================================================================
*/
#ifndef MOTOR_H
#define MOTOR_H

#include <stdio.h>
#include <string.h>
#include "stm32f4xx_hal.h"

#if MOTOR_GLOBALS
	#define MOTOR_EXT 
#else
	#define MOTOR_EXT extern
#endif // MOTOR_GLOBALS
// -----------------------------------------------------------------------------
//------------------------------------------------------------------------------

#define DRVCS_OFF HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,GPIO_PIN_RESET)	//GPIO��Ϊ0
#define DRVCS_ON  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,GPIO_PIN_SET) 	  //GPIO��Ϊ1

#define DRVCLK_OFF HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,GPIO_PIN_RESET)	//GPIO��Ϊ0
#define DRVCLK_ON  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,GPIO_PIN_SET) 	  //GPIO��Ϊ1
	
#define DRVDI_0 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_RESET)	//GPIO��Ϊ0
#define DRVDI_1  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_SET) 	  //GPIO��Ϊ1
	
#define DRVDO 		HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_4)  //��ȡ������������

#define DRV_nFAULT HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_12)  //��ȡ���������Ƿ����
// -----------------------------------------------------------------------------
//					GENERAL FUNCTION
MOTOR_EXT uint8_t motorbuf[4];
MOTOR_EXT uint8_t gc_MotorModeSelect;
MOTOR_EXT uint8_t gc_ExIntFlag;
//MOTOR_EXT uint8_t tmpHall[2]; //����ȥ��������
MOTOR_EXT uint8_t gc_Hall;
MOTOR_EXT uint8_t gc_prevHall;
MOTOR_EXT uint8_t gc_MDir;
//MOTOR_EXT uint32_t BLDC_TIM_PERIOD;

MOTOR_EXT uint32_t gi_HallTime[12];
MOTOR_EXT uint32_t gi_DutyValue;
MOTOR_EXT uint32_t gi_MotorSpeedCnt;
MOTOR_EXT uint32_t gi_Timer6Cnt;
MOTOR_EXT int32_t gi_MotorSpeed;
MOTOR_EXT	uint16_t Drv_SetData[8];

MOTOR_EXT uint8_t gc_DRVFault;
MOTOR_EXT uint16_t gc_DRVFaultData[2];
//============================
MOTOR_EXT uint8_t is_Hall_or_Encoder; //ѡ����뷽ʽ�ǻ������Ǳ�����
MOTOR_EXT uint8_t gc_NumOfPole;   //������
MOTOR_EXT uint16_t gc_ReductionRatio;  //���ٱ�
MOTOR_EXT uint32_t gi_ZeroValue;  //���ֵ�����ڱ������������߶�Ӧ
MOTOR_EXT uint8_t  gc_CalZeroFlag;   //У׼����ʶλ
MOTOR_EXT uint8_t  gc_ZeroHall;   //У׼���ʱ�Ļ���ֵ
MOTOR_EXT uint32_t gi_EncoderValue; //�ű�������ֵ
MOTOR_EXT uint32_t gi_EncoderHall; //�ű�����ֵ��Ӧ�Ļ���ֵ


//===========================
	
void DRV_Init(void);
void DRV_WriteDta(uint8_t add,uint16_t dat);
uint16_t DRV_ReadData(uint8_t add);
	
void usr_Timer1_Init(void);
void usr_motor_ioInit(void);
void motor_enable(uint8_t enable);  //���ʹ��
void motor_start(void);
void motor_single_contorl_mode(uint8_t ch,uint8_t INL,uint8_t INH,uint8_t enable);
void PWM_T_Output(uint8_t dir,uint8_t step,uint32_t duty);
void Ctrl_Mode1_Pro(uint8_t step,uint32_t duty);
void Ctrl_Mode2_Pro(uint8_t step,uint32_t duty);
void Ctrl_Mode3_Pro(uint32_t duty);
void Ctrl_Mode4_Pro(uint32_t duty);
void CalZeroFun(void);  //�������趨
void motorEncoder_Start(void);
// -----------------------------------------------------------------------------
#endif // MOTOR_H
