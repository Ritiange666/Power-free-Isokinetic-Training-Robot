/**
  ******************************************************************************
  * File Name          : UART2Pro.c
  * Description        : ����2��ͨ�Ŵ���
  ******************************************************************************
  *
  */
#include "stm32f4xx_hal.h"
#include "gPara.h"
#include "string.h"
#include "math.h"
#include "UARTPro.h"

#ifndef UART3_DMA
#define UART3_DMA
#endif
USART_RECEIVETYPE UsartType3;

void USRT3_SendByte(uint8_t ch)
{
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);
	huart3.Instance->DR = ch;
	while ((huart3.Instance->SR & 0X40) == 0);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
}

void UART3_IT_Init(void)
{
		 HAL_UART_Receive_DMA(&huart3, UsartType3.usartDMA_rxBuf, RECEIVELEN);  
		__HAL_UART_ENABLE_IT(&huart3, UART_IT_IDLE);
}

void UART3_DMA_REVC(void)
{  
    uint32_t temp;  
		int16_t dataii;
    if((__HAL_UART_GET_FLAG(&huart3,UART_FLAG_IDLE) != RESET))  
    {   
        __HAL_UART_CLEAR_IDLEFLAG(&huart3);  
        HAL_UART_DMAStop(&huart3);  
        temp = huart3.hdmarx->Instance->NDTR;  
        UsartType3.rx_len =  RECEIVELEN - temp;
        HAL_UART_Receive_DMA(&huart3,UsartType3.usartDMA_rxBuf,RECEIVELEN);
			
			//HAL_UART_Transmit_DMA(&huart3, &UsartType1.usartDMA_rxBuf[0], UsartType1.rx_len);		
			
        if(UsartType3.rx_len>=8)   //��ȡ��������λ�����ݺ��ٶ���Ϣ��RS485ͨ�ţ�
				{
					gt_MInfo.Angle = ((int32_t)UsartType3.usartDMA_rxBuf[2]<<16) | ((int32_t)UsartType3.usartDMA_rxBuf[3]<<8) | UsartType3.usartDMA_rxBuf[4];  //�Ƕ�
//					gt_MInfo.Angle -= 640;
					dataii = (((int32_t)UsartType3.usartDMA_rxBuf[5]<<8) | UsartType3.usartDMA_rxBuf[6])*6;  //�ٶ�
					gt_MInfo.Mot_Speed = dataii;
				}
    }
		else if(__HAL_UART_GET_FLAG(&huart3,UART_FLAG_TC) != RESET)
		{
			__HAL_UART_DISABLE_IT(&huart3, UART_IT_TC);
			huart3.gState = HAL_UART_STATE_READY;
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
		}
		else;
}



void UART3_Send(uint8_t *TX3_DMABuf,  uint16_t iDMA_Index)
{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);
		//__HAL_UART_ENABLE_IT(&huart3, UART_IT_TC);
		__HAL_UART_CLEAR_FLAG(&huart3, UART_IT_TC);
#if defined(UART3_DMA)
    HAL_UART_Transmit_DMA(&huart3,TX3_DMABuf,iDMA_Index);
    iDMA_Index=0;
#endif
}

/***********************
* CRC-8����(x^8+1)
* //poly=x^8+1
*************************/
uint8_t calcCRC(uint8_t *buffer,uint8_t length)
{
	uint8_t temp = *buffer++;
	while(--length)
	{
		temp = *buffer++ ^ temp;
	}
	return temp;
}



