/*
** =============================================================================
** UARTPro.h :                        -- by ZSC     2017-01-04
**
** 	Some useful Parameter for UART.
**    
** =============================================================================
*/
#ifndef UARTPRO_H
#define UARTPRO_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "stm32f4xx_hal.h"

#if UARTPRO_GLOBALS
	#define UARTPRO_EXT 
#else
	#define UARTPRO_EXT extern
#endif // UARTPRO_GLOBALS
// -----------------------------------------------------------------------------
//------------------------------------------------------------------------------
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart3;
extern UART_HandleTypeDef huart4;
	
#define TICK_NUM 3
	
// -----------------------------------------------------------------------------
#define RECEIVELEN 128 		//���ܵ����ݳ���
typedef struct  
{  
	uint32_t rx_len;					//���յ������ݳ���
	uint8_t usartDMA_rxBuf[RECEIVELEN];//DMA���յ��Ĵ�����������
}USART_RECEIVETYPE;

UARTPRO_EXT uint8_t TXBuf[544];

UARTPRO_EXT uint32_t 	send_tick;
UARTPRO_EXT uint16_t DMA_Len;
UARTPRO_EXT uint8_t gc_TxView;
UARTPRO_EXT uint8_t gc_TxFormat;
UARTPRO_EXT uint8_t DataSave[32];
//					GENERAL FUNCTION

void UART1_IT_Init(void);
void UART1_DMA_REVC(void);
void UART1_Send(uint8_t *TX2_DMABuf,  uint16_t iDMA_Index);

void DataInit(void);
void uart_sendDataFun(void);
extern int32_t speed_temp;//Feng

UARTPRO_EXT uint8_t TX3Buf[8];
void USRT3_SendByte(uint8_t ch);
void UART3_IT_Init(void);
void UART3_DMA_REVC(void);
void UART3_Send(uint8_t *TX3_DMABuf,  uint16_t iDMA_Index);
uint8_t calcCRC(uint8_t *buffer,uint8_t length);

void UART4_IT_Init(void);
void UART4_DMA_REVC(void);
void UART4_Send(uint8_t *TX3_DMABuf,  uint16_t iDMA_Index);
// -----------------------------------------------------------------------------
#endif // UARTPRO_H
