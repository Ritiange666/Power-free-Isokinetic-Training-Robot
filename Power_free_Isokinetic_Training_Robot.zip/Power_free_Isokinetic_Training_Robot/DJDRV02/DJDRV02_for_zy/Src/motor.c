/**
  ******************************************************************************
  * File Name          : motor.c
  * Description        : ������Ƴ���
  ******************************************************************************
  *
  */
#include "main.h"
#include "stm32f4xx_hal.h"
#include "gPara.h"
#include "string.h"
#include "math.h"
#include "UARTPro.h"
#include	"ADC.h"
#define MOTOR_GLOBALS 1
#include	"motor.h"

#define BLDC_TIM_PERIOD 3360
uint8_t hall[6] = {1,3,2,6,4,5};

void HAL_TIM_MspPostInit(TIM_HandleTypeDef* htim);


//��ʱ��ģʽPWM���
void usr_Timer1_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_OC_InitTypeDef sConfigOC;
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig;

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 4200-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;//2100;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_ENABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  HAL_TIM_MspPostInit(&htim1);

	//HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
	
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);//������ʱ��1ͨ��1��PWM���
	//HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_1);//ֹͣ��ʱ��1ͨ��1��PWM���
	//gi_DutyValue = TIM1->CCR1;
	TIM1->CCR1=BLDC_TIM_PERIOD; //����TIMͨ��1��PWMռ�ձ�
	TIM1->CCR2=BLDC_TIM_PERIOD; //����TIMͨ��1��PWMռ�ձ�
	TIM1->CCR3=BLDC_TIM_PERIOD; //����TIMͨ��1��PWMռ�ձ�
}

//IO����ģʽ
void usr_motor_ioInit(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	 __HAL_RCC_GPIOA_CLK_ENABLE();
	
	GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/*****************��������ʱ�ӳ���**************************/
void Delayus(uint32_t u)
{
	for(uint32_t i=0;i<u;i++)
		for(uint32_t j=0;j<80;j++);
}

/*****************��������ʼ��**************************/
void DRV_Init(void)
{
	motor_enable(0);
	DRVCS_ON;
	DRVCLK_OFF;
	DRVDI_0;
	HAL_Delay(100);
	DRV_WriteDta(3,0x3FF); //����
	HAL_Delay(10);
	DRV_WriteDta(2,0x20); //
	DRV_WriteDta(3,0x366); //
	DRV_WriteDta(4,0x666); //
	DRV_WriteDta(5,0x155); //
	DRV_WriteDta(6,0x2C0); //
	HAL_Delay(10);
	DRV_WriteDta(3,0x666); //
	
	for(int i=0;i<7;i++)
		Drv_SetData[i] = DRV_ReadData(i);
}

/*****************������д�Ĵ���**************************/
void DRV_WriteDta(uint8_t add,uint16_t dat)
{
	uint16_t data = add;
	DRVCLK_OFF;
	Delayus(1);
	DRVCS_OFF;
	data = ((data<<11) & 0x7800) | (dat&0x7FF);
	Delayus(1);
	for(uint8_t i=0;i<16;i++)
	{
		DRVCLK_ON;
		if(data&0x8000)
			DRVDI_1;
		else
			DRVDI_0;
		Delayus(1);
		DRVCLK_OFF;
		data = data<<1;
		Delayus(1);
	}
	DRVCS_ON;
}

/*****************���������Ĵ���**************************/
uint16_t DRV_ReadData(uint8_t add)
{
	uint16_t data = add;
	uint16_t ret = 0;
	DRVCLK_OFF;
	Delayus(1);
	DRVCS_OFF;
	data = (data<<11) | 0x8000;
	Delayus(1);
	for(uint8_t i=0;i<16;i++)
	{
		DRVCLK_ON;
		if(data&0x8000)
			DRVDI_1;
		else
			DRVDI_0;
		Delayus(1);
		DRVCLK_OFF;
		data = data<<1;
		ret = ret<<1;
		Delayus(10);
		if(DRVDO == 1)
			ret = ret|1;
	}
	ret = ret&0x7FF;
	DRVCS_ON;
	return ret;
}

/*****************�������ʹ��**************************/
void motor_enable(uint8_t enable)
{
	if(enable ==1)
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_SET);
	else
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_RESET);
}
/*****************���Mos�ܶ�������ģʽ**************************/
void motor_single_contorl_mode(uint8_t ch,uint8_t INL,uint8_t INH,uint8_t enable)
{
	HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_1);
	HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_2);
	HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_3);
	usr_motor_ioInit();
//	if(enable == 1)
//		motor_enable(1);
//	else
//		motor_enable(0);
	switch(ch)
	{
		case 1:  //A/U
			if(enable == 1)
			{
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,INL);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,INH);
			}
			else
			{
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,0);
			}
			break;
		case 2:  //B/V
			if(enable == 1)
			{
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,INL);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,INH);
			}
			else
			{
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,0);
			}
			break;
		case 3:  //C/W
			if(enable == 1)
			{
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,INL);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,INH);
			}
			else
			{
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,0);
			}
			break;
		default:break;
	}
}


/******************PWM���**************************/
/*******************************************
* ������PWM_T_Output
* ������������Ӧ��PWM���β����
* ������Step����ֵ
* ���أ���
*********************************************/
void PWM_T_Output(uint8_t dir,uint8_t step,uint32_t duty)
{
	if(dir == 1)
	{
		switch(step)
		{
			case 5: //B+ A-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				break;
			case 1: //C+ A-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				break;
			case 3: //C+ B-
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				break;
			case 2: //A+ B-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				break;
			case 6: //A+ C-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				break;
			case 4: //B+ C-
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				break;
			default: //All disable
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_DISABLE);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_DISABLE);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_DISABLE);
				break;
		}
	}
	else
	{
		switch(step)
		{
			case 5: //A+ B-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				break;
			case 1: //A+ C-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				break;
			case 3: //B+ C-
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				break;
			case 2: //B+ A-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				break;
			case 6: //C+ A-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				break;
			case 4: //C+ B-
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				break;
			default: //All disable
				break;
		}
	}
}

/***********************************
*�������
*************************************/
void motor_start(void)
{
	//motor_enable(1);
	//gc_MDir = 0;
	//gi_DutyValue = 10;
	PWM_T_Output(gc_MDir,gc_Hall,gi_DutyValue);
}



/***********************************
*ֹͣ���
*************************************/
void motor_stop(void)
{
	PWM_T_Output(1,7,0);
	motor_enable(1);
}

/******************Ƶ�����**************************/
/*******************************************
* ������Ctrl_Mode1_Pro
* ������������Ӧ�Ŀ��ؿ������������ģʽ
* ������Step����ֵ
* ���أ���

*********************************************/
void Ctrl_Mode1_Pro(uint8_t step,uint32_t duty)
{
		switch(step)
		{
			case 5: //B+ A-
				//HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);  //L
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,0); //A_H
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,0); //B
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,0); //C
				
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				delay_us1(duty);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
				delay_us1(100-duty);
				break;
			case 1: //C+ A-
				//HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);  //L
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,0); //A_H
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,0); //B
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,0); //C
				
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				delay_us1(duty);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
				delay_us1(100-duty);
				break;
			case 3: //C+ B-
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);  //L
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,0); //A_H
				//HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,0); //B
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,0); //C
				
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				delay_us1(duty);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				delay_us1(100-duty);
				break;
			case 2: //A+ B-
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);  //L
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,0); //A_H
				//HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,0); //B
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,0); //C
				
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				delay_us1(duty);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				delay_us1(100-duty);
				break;
			case 6: //A+ C-
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);  //L
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,0); //A_H
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,0); //B
				//HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,0); //C
				
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				delay_us1(duty);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				delay_us1(100-duty);
				break;
			case 4: //B+ C-
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);  //L
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,0); //A_H
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,0); //B
				//HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,0); //C
				
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				delay_us1(duty);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				delay_us1(100-duty);
				break;
			default: //All disable
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);  //L
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,0); //A_H
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,0); //B
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,0); //C
				break;
		}
	
}

/******************Ƶ�����**************************/
/*******************************************
* ������Ctrl_Mode2_Pro
* ������������Ӧ�Ŀ��ؿ������������ģʽ
* ������Step����ֵ
* ���أ���
*********************************************/
void Ctrl_Mode2_Pro(uint8_t step,uint32_t duty)
{
		switch(step)
		{
			case 5: //B+ A-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				break;
			case 1: //C+ A-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				break;
			case 3: //C+ B-
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				break;
			case 2: //A+ B-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				break;
			case 6: //A+ C-
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
				TIM1->CCR1=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				break;
			case 4: //B+ C-
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_DISABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
				TIM1->CCR2=BLDC_TIM_PERIOD;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
				TIM1->CCR3=BLDC_TIM_PERIOD*duty/4200;
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
				break;
			default: //All disable
				HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_DISABLE);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_DISABLE);
				TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_DISABLE);
				break;
		}
	
}

/******************Ƶ�����**************************/
/*******************************************
* ������Ctrl_Mode3_Pro
* ������������Ӧ�Ŀ��ؿ������������ģʽ
* ������dutyռ�ձȵ���
* ���أ���
*********************************************/
void Ctrl_Mode3_Pro(uint32_t duty)
{
//	HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_1);
//	HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_2);
//	HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_3);
//	usr_motor_ioInit();
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,0); //A_H
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,0); //B
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,0); //C
	
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
	delay_us1(duty);
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,0);
	delay_us1(100-duty);
}

/******************Ƶ�����**************************/
/*******************************************
* ������Ctrl_Mode4_Pro
* ������������Ӧ�Ŀ��ؿ������������ģʽ
* ������dutyռ�ձȵ���
* ���أ���
*********************************************/
void Ctrl_Mode4_Pro(uint32_t duty)
{
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,1);
	TIM1->CCR1=4199*duty/2000;
	TIM1->CCR2=4199*duty/2000;
	TIM1->CCR3=4199*duty/2000;
	TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
	TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
	TIM_CCxChannelCmd(htim1.Instance, TIM_CHANNEL_3, TIM_CCx_ENABLE);
}

//���У׼
void CalZeroFun(void)
{
	if(is_Hall_or_Encoder == 2)
	{
		usr_Timer1_Init();
//		gc_MDir = 1;
//		gi_DutyValue = 3700;
		gi_ZeroValue = gi_EncoderValue;
		for(uint8_t i=0;i<6;i++)  //������ʹ����˶��ĵ�ǰ����ֵ
		{//uint8_t hall[6] = {1,3,2,6,4,5};
			PWM_T_Output(gc_MDir,hall[i],3700); 
			HAL_Delay(1500);
			PWM_T_Output(1,0,4199);
			HAL_Delay(500);
			if(((gi_ZeroValue - gi_EncoderValue)>10 && (gi_ZeroValue - gi_EncoderValue)<(600/gc_NumOfPole+200)) || ((gi_EncoderValue - gi_ZeroValue)>10 && (gi_EncoderValue - gi_ZeroValue)<(600/gc_NumOfPole+200)))
			{
				if(gi_ZeroValue > gi_EncoderValue)
				{
					if(i==0)
						gc_ZeroHall = 5;
					else
						gc_ZeroHall = i-1;
				}
				else
				{
					if(i==5)
						gc_ZeroHall = 0;
					else
						gc_ZeroHall = i+1;
				}
				gi_ZeroValue = gi_EncoderValue;
				DataSave[0] = gi_ZeroValue;
				DataSave[1] = gi_ZeroValue>>8;
				DataSave[2] = gi_ZeroValue>>16;
				DataSave[3] = gi_ZeroValue>>24;
				DataSave[4] = gc_ZeroHall;
				I2C_EEPROM_WriteBuffer(0x24,DataSave,5); //�洢��ǰ�����ֵ�Ͷ�Ӧ�Ļ���ֵ
				break;
			}
		}
	}
}

//�Ƕ������ֵ��Ӧ���뼫�����й�
void CoderToAngle(void)
{
	int i,j;
	i = ((((int)gi_EncoderValue - (int)gi_ZeroValue)*gc_NumOfPole)/600)%6;
	j = gc_ZeroHall+i;
	if(j>5)
		gi_EncoderHall = j-5;
	else if(j<0)
		gi_EncoderHall = 5+j;
	else
		gi_EncoderHall = j;
}

//�ű�������Ӧ�µĵ���˶�
void motorEncoder_Start(void)
{
	CoderToAngle();
	if(gi_EncoderHall >= 5)
		gi_EncoderHall = 0;
	else
		gi_EncoderHall = gi_EncoderHall+1;
	PWM_T_Output(gc_MDir,hall[gi_EncoderHall],gi_DutyValue);
}




