/*
** =============================================================================
** ADC.h :                        -- by ZSC     2017-01-04
**
** 	Some useful Parameter for ADC.
**    
** =============================================================================
*/
#ifndef ADC_H
#define ADC_H

#include <stdio.h>
#include <stdlib.h>
#include "stm32f4xx_hal.h"

#if ADC_GLOBALS
	#define ADC_EXT 
#else
	#define ADC_EXT extern
#endif // ADC_GLOBALS
// -----------------------------------------------------------------------------
//------------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#define		ADCBUFLEN		100
	
ADC_EXT		uint8_t		gc_ADCSamplingFlag;
ADC_EXT		uint32_t 	ADC1_Buf[ADCBUFLEN];
ADC_EXT		uint32_t 	ADC2_Buf[ADCBUFLEN];
ADC_EXT		uint32_t	gi_ADC1Value[5];
ADC_EXT		uint32_t	gi_ADC2Value[5];
//					GENERAL FUNCTION
void ADC_data_Init(void);
void ADC_SamplingPro(void);
// -----------------------------------------------------------------------------
#endif // ADC_H
