/*
** =============================================================================
** gPara.h :                        -- by ZSC     2017-01-04
**
** 	Some useful Parameter.
**    
** =============================================================================
*/
#ifndef GPARA_H
#define GPARA_H

#include <stdio.h>
#include <string.h>
#include "stm32f4xx_hal.h"

#if GPARA_GLOBALS
	#define GPARA_EXT 
#else
	#define GPARA_EXT extern
#endif // GPARA_GLOBALS
// -----------------------------------------------------------------------------
//------------------------------------------------------------------------------

#define LED1_OFF HAL_GPIO_WritePin(GPIOC,GPIO_PIN_14,GPIO_PIN_RESET)	//GPIO��Ϊ0 LED��
#define LED1_ON  HAL_GPIO_WritePin(GPIOC,GPIO_PIN_14,GPIO_PIN_SET) 	  //GPIO��Ϊ1
#define LED2_OFF HAL_GPIO_WritePin(GPIOC,GPIO_PIN_15,GPIO_PIN_RESET)  //GPIO��Ϊ0 LED��
#define LED2_ON  HAL_GPIO_WritePin(GPIOC,GPIO_PIN_15,GPIO_PIN_SET)
#define LED1_Toggle HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_14)		//��GPIOȡ���ԴﵽʹLED��˸��Ч��
#define LED2_Toggle HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_15)	
	
#define PWR_CHG1  HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,GPIO_PIN_SET) 	  //GPIO��Ϊ1���������ݷŵ�
#define PWR_CHG0  HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,GPIO_PIN_RESET) 	  //GPIO��Ϊ0���������ݷŵ�̵����Ͽ�
	
#define PWRLED1_ON 	 HAL_GPIO_WritePin(GPIOC,GPIO_PIN_12,GPIO_PIN_RESET)	//GPIO��Ϊ0 LED��
#define PWRLED1_OFF  HAL_GPIO_WritePin(GPIOC,GPIO_PIN_12,GPIO_PIN_SET) 	  //GPIO��Ϊ1

#define SWInput HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_9)  //��ȡ���ص�����

// -----------------------------------------------------------------------------
//					GENERAL FUNCTION
extern I2C_HandleTypeDef hi2c1;
extern ADC_HandleTypeDef hadc1;	
extern ADC_HandleTypeDef hadc2;	
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim3;

extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart3;
extern UART_HandleTypeDef huart4;
//GPARA_EXT unsigned char gLedTwinkleFlag;	

typedef struct
{
	uint8_t header[2]; //����ͷ0xAA55
	uint8_t key;  //�ؼ��� 0x01
	uint8_t mode; //����ģʽ
	uint8_t Value1; //
	uint8_t value2; //ֵ0x00
	uint8_t tail[2];  //����β0x0D0A
} ST_WMODE;   //8���ֽ�

typedef struct
{
	uint8_t header[2]; //����ͷ0xAA55
	uint8_t key;  //�ؼ��� 0x01
	uint8_t mode; //����ģʽ
	int32_t S;
	int32_t P;
	int32_t I;
	int32_t D;
	int32_t LMT_MAX;
	int32_t LMT_MIN;
	uint16_t Status; //
	uint8_t tail[2];  //����β0x0D0A
} ST_PID;  //32���ֽ�

typedef struct
{
	uint8_t header[2]; //����ͷ0xAA55
	uint8_t key;  //�ؼ��� 0x01
	uint8_t mode; //����ģʽ
	int32_t value;
	int32_t NC;
	uint16_t Status; //
	uint8_t tail[2];  //����β0x0D0A
} ST_MRUN;  //16���ֽ�

typedef struct
{
	uint8_t header[2]; //����ͷ0xAA55
	uint8_t cmd;  //�ؼ��� 0x01
	uint8_t mode; //����ģʽ
	int32_t Sys_Vol;
	int32_t Sys_Cur;
	int32_t CHG_Vol;
	int32_t CHG_Cur;
	int32_t Mot_Vol; //
	int32_t Mot_Cur;
	int32_t Mot_Speed;
	int32_t Angle;
	int32_t Temp;
	int32_t Set_Speed;
	int32_t NC;
	uint16_t Status; //Status+HALL(��8λ״̬�룬��8��Hallֵ)
	uint8_t tail[2];  //����β0x0D0A
} ST_MINFO;  //52���ֽ�


GPARA_EXT ST_PID gt_PID[7];
GPARA_EXT ST_MINFO gt_MInfo;
GPARA_EXT ST_MRUN gt_MRun;

GPARA_EXT float gf_torque;
GPARA_EXT uint8_t SWState;
GPARA_EXT uint8_t SetZero;


void delay_us1(uint32_t u); //1uS��ʱ
//void _Error_Handler(void);

//------------------I2C����-------------------------------------------------
void MX_I2C1_eeprom_Init(void);
HAL_StatusTypeDef I2C_EEPROM_WriteBuffer(uint16_t Reg,uint8_t *pBuffer, uint16_t Length);
HAL_StatusTypeDef I2C_EEPROM_ReadBuffer(uint16_t Reg, uint8_t *pBuffer, uint16_t Length);




// -----------------------------------------------------------------------------
#endif // GPARA_H
